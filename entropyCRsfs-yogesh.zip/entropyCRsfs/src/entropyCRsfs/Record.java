package entropyCRsfs;

import java.util.List;


public class Record {

	public List<String> GeneList;
	public String Class;
	
}
