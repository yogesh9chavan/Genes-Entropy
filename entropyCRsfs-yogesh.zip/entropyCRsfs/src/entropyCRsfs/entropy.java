package entropyCRsfs;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Frame;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.RowSorter;
import javax.swing.SortOrder;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;
import java.util.stream.Stream;

import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

public class entropy extends JFrame {

	public JPanel contentPane;
	private JTextField tfDataFilePath;
	private static JTable table;
	private DefaultTableModel model;
	private static int numberOfRows = 0;
	private static int numberOfColumns = 0;
	private List<Record> recordList;
	RowSorter<TableModel> sorter;
	File dataFile;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					entropy frame = new entropy();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public static <K, V extends Comparable<? super V>> Map<K, V> 
    sortByValue( Map<K, V> map )
    {
      Map<K,V> result = new LinkedHashMap<>();
      Stream <Entry<K,V>> st = map.entrySet().stream();

      st.sorted(Comparator.comparing(e -> e.getValue()))
          .forEach(e ->result.put(e.getKey(),e.getValue()));

      return result;
    }
	
	public static void OrderGenes(int columns, String fileName)
	{
		columns++;
		DefaultTableModel dtm = (DefaultTableModel)table.getModel();
		Map<String, String> mappedRecords = new HashMap<String, String>();
		Map<String,Double> gainRecords = new HashMap<String,Double>();
		Map<String, Double> sortedGainRecords = new HashMap<String,Double>();
		List<Double> geneValues = new ArrayList<Double>();
		List<String> classNames = new ArrayList<String>();
		for(int i = 0; i < columns-1; i++)
		{
			List<String> tuples = new ArrayList<String>();
			List<String> columnSplitRecords = new ArrayList<String>();
			List<Double> intraColumnSplitGains = new ArrayList<Double>();
			int pClassCount = 0;
			int nClassCount = 0;
			Integer[] S1 = new Integer[2];
			Integer[] S2 = new Integer[2];
			double entropyOfS = 0;
			for(int j = 0; j < numberOfRows; j++)
			{
				//double geneValue = Double.parseDouble(dtm.getValueAt(j, i).toString());
				//Tuple tuple = new Tuple(geneValue, dtm.getValueAt(j, numberOfColumns-1).toString());
				String tuple = "("+ dtm.getValueAt(j, i).toString()+ "," + dtm.getValueAt(j, numberOfColumns-1).toString()+")";
				//geneValues.add(geneValue);
				//classNames.add(dtm.getValueAt(j, numberOfColumns-1).toString());
				tuples.add(tuple);
			}
			
			Collections.sort(tuples);
			
			for(int t=1; t<= tuples.size() - 1; t++)
			{
			    if(tuples.get(t).contains("positive"))
					  pClassCount++;
				else if(tuples.get(t).contains("negative"))
					  nClassCount++;
			}
			
			entropyOfS = (((-pClassCount*(Math.log(pClassCount)/Math.log(2) - Math.log(pClassCount+nClassCount)/Math.log(2)))/(pClassCount+nClassCount))
					      - (nClassCount*(Math.log(nClassCount)/Math.log(2) - Math.log(pClassCount+nClassCount)/Math.log(2)))/(pClassCount+nClassCount));
			
			
			//System.out.println("TEST :" + entropyOfS);
			
			pClassCount = 0;
			nClassCount = 0;
			
			for(int a=1; a<= tuples.size() - 1; a++)
			{
			  List<String> bin1 = tuples.subList(0, a);
			  List<String> bin2 = tuples.subList(a, tuples.size());
			  int commaIndex = bin1.get(bin1.size()-1).indexOf(',');
			  double preSplitValue = Double.parseDouble(bin1.get(bin1.size()-1).subSequence(1, commaIndex).toString());
			  commaIndex = bin1.get(0).indexOf(',');
			  double postSplitValue = Double.parseDouble(bin2.get(0).subSequence(1, commaIndex).toString());
			  
			  //System.out.println(preSplitValue);
			  //System.out.println(postSplitValue);
			  for(int b = 0; b<bin1.size();b++)
			  {
				  if(bin1.get(b).contains("positive"))
					  pClassCount++;
				  else if(bin1.get(b).contains("negative"))
					  nClassCount++;
				  
			  }
			  S1[0] = pClassCount;
			  S1[1] = nClassCount;
			  pClassCount = 0;
			  nClassCount = 0;
			  
			  for(int c = 0; c<bin2.size();c++)
			  {
				  if(bin2.get(c).contains("positive"))
					  pClassCount++;
				  else if(bin2.get(c).contains("negative"))
					  nClassCount++;
			  }
			  S2[0] = pClassCount;
			  S2[1] = nClassCount;
			  pClassCount = 0;
			  nClassCount = 0;
			  double entropyOfS1 = (((-S1[0]*(Math.log(S1[0])/Math.log(2) - Math.log(S1[0]+S1[1])/Math.log(2)))/(S1[0]+S1[1]))
				      - (S1[1]*(Math.log(S1[1])/Math.log(2) - Math.log(S1[0]+S1[1])/Math.log(2)))/(S1[0]+S1[1]));
			  
			  if(Double.isNaN(entropyOfS1))
				  entropyOfS1 = 0;

			  
			  double entropyOfS2 = (((-S2[0]*(Math.log(S2[0])/Math.log(2) - Math.log(S2[0]+S2[1])/Math.log(2)))/(S2[0]+S2[1]))
				      - (S2[1]*(Math.log(S2[1])/Math.log(2) - Math.log(S2[0]+S2[1])/Math.log(2)))/(S2[0]+S2[1]));
			  
			  if(Double.isNaN(entropyOfS2))
				  entropyOfS2 = 0;
			  //System.out.println("S1 :" + entropyOfS1);
			  //System.out.println("E" + entropyOfS+"-" + entropyOfS1+"-" + entropyOfS2);
			  double iSOfS1S2 = (((S1[0]+S1[1])*entropyOfS1)/tuples.size() + ((S2[0]+S2[1])*entropyOfS2)/tuples.size());
			  if(Double.isNaN(iSOfS1S2))
				  iSOfS1S2 = 0;
			  //System.out.println("IS" + iSOfS1S2 );
			  double gain = entropyOfS - iSOfS1S2 ;
			  DecimalFormat twoDForm = new DecimalFormat("#.###");
			  String columnSplitRecord = ""+ (twoDForm.format((preSplitValue + postSplitValue)/2))+ ",("+S1[0]+" "+S1[1]+"), (" +S2[0]+" "+S2[1]+")," +twoDForm.format(iSOfS1S2);
			 // System.out.println(columnSplitRecord);
			  columnSplitRecords.add(columnSplitRecord);
			  if(Double.isNaN(gain))
				  gain = 0;
			  intraColumnSplitGains.add(gain);
			}
			int maxGainIndex = intraColumnSplitGains.indexOf(Collections.max(intraColumnSplitGains));
			String maxGainRecord = columnSplitRecords.get(maxGainIndex);
			gainRecords.put(dtm.getColumnName(i), intraColumnSplitGains.get(maxGainIndex));
			mappedRecords.put(dtm.getColumnName(i), maxGainRecord);
		}	
		sortedGainRecords = sortByValue(gainRecords);
		try {
			PrintWriter pw = new PrintWriter(fileName, "UTF-8");
			Object[] keys = sortedGainRecords.keySet().toArray();
			pw.println("Gene Number---Split Value------S1-----S2----------IS------");
			pw.println();
			//System.out.println(keys);
			for(int i = sortedGainRecords.size()-1; i>=0;i--)
			{
				String record = mappedRecords.get(keys[i]);
				String[] records = record.split(",");
				pw.println(keys[i] +"-----------"+records[0]+"------"+records[1]+"---"+records[2]+"------"+records[3]);
			}
			pw.close();
		} catch (FileNotFoundException | UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Create the frame.
	 */
	public entropy() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(250, 150, 767, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnBrowse = new JButton("Browse");	
		btnBrowse.setBounds(435, 16, 89, 23);
		contentPane.add(btnBrowse);
		
		JLabel lblDataFile = new JLabel("Data File");
		lblDataFile.setBounds(40, 20, 61, 14);
		contentPane.add(lblDataFile);
		
		tfDataFilePath = new JTextField();
		tfDataFilePath.setBounds(111, 17, 314, 20);
		contentPane.add(tfDataFilePath);
		tfDataFilePath.setColumns(10);
		
		table = new JTable();
		JScrollPane scrollPane = new JScrollPane(table);
		table.setFillsViewportHeight(true);
		scrollPane.setBounds(40, 52, 484, 346);
		contentPane.add(scrollPane);
		
		JButton btnGenesEnrtopyOrder = new JButton("Genes Entropy Order");
		btnGenesEnrtopyOrder.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(recordList.isEmpty())
					return;
				OrderGenes(numberOfColumns-1,"GenesEntropyOrder.txt");
				JOptionPane.showMessageDialog(null,"Genes are ordered. Check GenesEntropyOrder.txt", "Message", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		
		
		btnGenesEnrtopyOrder.setBounds(554, 52, 171, 23);
		contentPane.add(btnGenesEnrtopyOrder);
		
		JButton btnNewButton = new JButton("Data Entropy Method");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					
					String inputNumberOfColumns = (String)JOptionPane.showInputDialog(
		                    new Frame(),
		                    "Enter number of columns",
		                    "User input",
		                    JOptionPane.PLAIN_MESSAGE,
		                    null,
		                    null, null);
					
					if(inputNumberOfColumns == "")
						return;
					
					int inputOfColumns = Integer.parseInt(inputNumberOfColumns);
					if(inputOfColumns > numberOfColumns-1)
						JOptionPane.showMessageDialog(null,"Number entered is more than the records available", "Error", JOptionPane.ERROR_MESSAGE);
					OrderGenes(inputOfColumns, "DataEntropyMethod.txt");
					JOptionPane.showMessageDialog(null,"Given number of Genes are ordered. Check DataEntropyMethod.txt", "Message", JOptionPane.INFORMATION_MESSAGE);
					//UserDataInput inputObj = new UserDataInput();
					//inputObj.main(null);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			}
		});
		btnNewButton.setBounds(554, 96, 171, 23);
		contentPane.add(btnNewButton);
		
		btnBrowse.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser chooser = new JFileChooser();
	            chooser.setCurrentDirectory(new java.io.File("."));
	            chooser.setDialogTitle("Select the file");
	            chooser.setFileSelectionMode(JFileChooser.OPEN_DIALOG);
	            chooser.showOpenDialog(null);
	            dataFile = chooser.getSelectedFile();
	            if(dataFile != null)
	            {
		            tfDataFilePath.setText(dataFile.getAbsolutePath());
		            tfDataFilePath.setEnabled(false);
		            ArrayList<String> columnNames = new ArrayList<String>();
		            try 
		            {
		            	BufferedReader reader = new BufferedReader(new FileReader((String)dataFile.getAbsolutePath()));
		    			String line = null;
		    			recordList = new ArrayList<Record>();
	    				//recordList.clear();
		    			while((line = reader.readLine()) != null)
		    			{
		    				String[] values = line.split(",");
		    				Record recordObj = null;
		    				for(String str : values)
		    				{
		    					numberOfColumns++;
		    					if(recordObj == null)
		    					{
		    						recordObj = new Record();
		    						recordObj.GeneList = new ArrayList<String>();
		    					}
		    					if(str.equals("positive") || str.equals("negative"))
		    					{
		    						
		    						numberOfRows++;
		    						recordObj.Class = str;
		    						recordObj.GeneList.add(str);
		    						recordList.add(recordObj);
		    						recordObj = null;
		    					}
		    					else
		    					{
		    						recordObj.GeneList.add(str);
		    					}
		    				}
		    			}
		    			reader.close();
		    			numberOfColumns = numberOfColumns/numberOfRows; 
		    			for(int i = 1; i <= numberOfColumns - 1; i++)
		    			{
		    				columnNames.add("g" + i);
		    			}
		    			columnNames.add("Class");
		    			String[] columns = columnNames.toArray(new String[columnNames.size()]);
		    			table.setModel(new DefaultTableModel(columns, 0));
		    			table.setAutoResizeMode(0);
		    			model = (DefaultTableModel)table.getModel();
		    			String[] columnData;
		    			for(Record recordObj : recordList)
		    			{
		    				columnData = recordObj.GeneList.toArray(new String[recordObj.GeneList.size()]);
		    				model.addRow(columnData);
		    			}
		    			sorter = new TableRowSorter<TableModel>(model);
		    		    table.setRowSorter(sorter);
					} 
		            catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	            }

			}
		});

	}
}

