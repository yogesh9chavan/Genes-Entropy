-To open the code and run the application, follow the below steps:

1. Open Eclipse
2. Click on File menu and then Open file menu option
3. Open entropy.java file
4. Run the program


-To run the application directly double click on entropyCRsfs.exe

-Sample results are in sampleResults.txt

-Notes and snapshots are in notes.doc
